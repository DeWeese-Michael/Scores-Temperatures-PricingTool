/*
Michael DeWeese
47659226
"Lab 4-Fall 2020"
*/
import java.util.Scanner;

public class PricingTool{
//global variable

	static Scanner scan = new Scanner(System.in);

	static double totalCost = 0.0;
	static double totalClientCost = 0.0;
	static String staffingProposal = "";
	static String[] employeeLevels = {"Consultant", "Senior Consultant", "Manager", "Senior Manager", "Principal"};
	//int[] newemployees=new int[5];
	static double[] hourlyRates = {35.00, 55.00, 65.00, 75.00, 100.00};
	static double[] hourlyBillRates = {135.00, 155.00, 165.00, 175.00, 200.00};

	public static void main(String[] args) {

		while(true){
			int option = displayMenu();

			if(option == 1){
				displayHourlyRates();
			}//end if option ==1

			else if(option == 2){	
				displayHourlyBillRates();
			}//end if option ==2

			else if(option ==3){
				staffProject();
			}//end option ==3
			
			else if(option == 4){
				displayProjectStaffingProposal();
			}//end if option ==4

			else if(option ==5){

				double profit=calculateProfit();
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				System.out.println("Your total cost of employee salaries per week is: ");
				System.out.println(totalCost);
				System.out.print("The total cost to the client per week is: ");
				System.out.println(totalClientCost);
				System.out.print("Your profit per week is: ");
				System.out.println(profit);
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

			}//end if option==5

			else if(option == 9){
				System.out.print("\nYou have successfully submitted your project proposal. ");
				System.out.println("Good-bye!");
				break;
			}//end if option ==9

			else {
				System.out.println("\nInvalid option");
			}

		}//end of while(true)
	}//end main method

	public static int displayMenu(){
		System.out.println("\nPlease choose from one of the following menu options - ");
		System.out.println("Welcome to the Pricing Tool");
		System.out.println("1) Display levels and hourly rates of consultants");
		System.out.println("2) Display levels and hourly bill rates of consultants");
		System.out.println("3) Staff project");
		System.out.println("4) Display project staffing proposal");
		System.out.println("5) Calculate profit");
		System.out.println("9) Submit project staffing proposal and exit");
		System.out.print("option:");

		int option = scan.nextInt();

		return option;

	}//end displayMenu

	public static void displayHourlyRates(){
		System.out.println("Levels and Hourly Rates");
		System.out.println("-----------------------");
		System.out.println("Employee Level      Hourly Rate");
		System.out.println("===============================");
		System.out.println("Consultant          $35.00");
		System.out.println("Senior Consultant   $55.00");
		System.out.println("Manager             $65.00");
		System.out.println("Senior Manager      $75.00");
		System.out.println("Principal           $100.00");


	}//end displayHourlyRates

	public static void displayHourlyBillRates(){
		System.out.println("Levels and Hourly Bill Rates");
		System.out.println("----------------------------");
		System.out.println("Employee Level      Hourly Rate");
		System.out.println("===============================");
		System.out.println("Consultant          $135.00");
		System.out.println("Senior Consultant   $155.00");
		System.out.println("Manager             $165.00");
		System.out.println("Senior Manager      $175.00");
		System.out.println("Principal           $200.00");

	}//end displayHourlyBillRates

	public static void staffProject(){
		//System.out.println("Your project will be staffed as follows: ");
		//System.out.println("\n4 Consultant(s) at 40.0 hours per week"); 
		//System.out.println("3 Senior Consultant(s) at 40.0 hours per week");
		//System.out.println("1 Manager(s) at 40.0 hours per week");
		//System.out.println("1 Senior Manager(s) at 20.0 hours per week");
		//System.out.println("1 Principal(s) at 10.0 hours per week");
		int num = 0;
		double hours = 0.0;
		//int i=0;


		while(true){
			System.out.println("\nHow do you want to staff your project? ");
			for(int i = 0; i < employeeLevels.length;i++)
				System.out.printf("Enter %d for %s\n",(i+1), employeeLevels[i]);

			System.out.println("Enter any other number when done. ");
			System.out.print("Level: ");
			int level = scan.nextInt();
			if(level ==1 || level == 2 || level ==3 || level == 4 || level == 5){

				double hourlyRate = hourlyRates[level-1];
				double hourlyBillRate = hourlyBillRates[level - 1];
				String employeeLevel = employeeLevels[level - 1];

				System.out.print("\nHow many " + employeeLevel +"(s) would you like to staff? ");
				num = scan.nextInt();
				//newemployees[i] = num;
				//i=i+1;
				hours = getHoursPerWeek();

				staffingProposal += num + " " + employeeLevel + "(s) at " + hours +" hours per week\n";

				updateTotalCost(num, hours, hourlyRate);
				updateTotalClientCost(num, hours, hourlyBillRate);

				System.out.printf("The current employee cost with an hourly rate of $%,.2f is %,.2f\n", hourlyRate, totalCost);
				System.out.printf("The current cost to the client with an hourly bill rate of $%,.2f is %,.2f\n", hourlyBillRate, totalClientCost);


			}//end if level loop
			else break;
		}//end while loop
	}//end staffProject

	public static double getHoursPerWeek(){

		System.out.print("How many hours per week? ");
		double hours = scan.nextDouble();

		return hours;

	}//end getHoursPerWeek

	public static void updateTotalCost(int num, double hours, double rate){
		totalCost += ((double)num)*hours*rate;
 

	}//end TotalCost

	public static void updateTotalClientCost(int num, double hours, double rate){
		totalClientCost += ((double)num)*hours*rate;

	}//end TotalClientCost

	public static void displayProjectStaffingProposal(){
		System.out.println(staffingProposal);

	}//end displayProjectStaffingProposal

	public static double calculateProfit(){
		return totalClientCost - totalCost;
	}//end calculateProfit

}//end class
