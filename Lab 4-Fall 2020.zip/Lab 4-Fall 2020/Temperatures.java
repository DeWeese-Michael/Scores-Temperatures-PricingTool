/*
Michael DeWeese
47659226
"Lab 4-Fall 2020"
*/
import java.util.Scanner;
public class Temperatures{

public static void main(String[] args) {

Scanner scan = new Scanner(System.in);
System.out.print("How many days' temperatures? ");
int days=scan.nextInt();

double[] temperatures = new double[days];

for(int i = 0; i < temperatures.length; i++){

System.out.print("Day ");
System.out.print(i+1);
System.out.print("'s high temp: ");

temperatures[i] = scan.nextDouble();
}//end for loop enter the days

double templength=(double)temperatures.length;

double totaltemp=0.0;
for(int i = 0; i < temperatures.length; i++){
 totaltemp = totaltemp + temperatures[i];
}//end for loop totaltemp

double avgtemp=totaltemp / templength;

System.out.print("\nThe Average temp = ");
System.out.println(avgtemp);

int count = 0;
for(int i = 0; i < temperatures.length; i++){
if(temperatures[i] > avgtemp){
count = count + 1;
}//end if counter
}//end for loop average temp

System.out.print(count);
System.out.print(" days above the average");
System.out.println();
}//end main method

}// end class