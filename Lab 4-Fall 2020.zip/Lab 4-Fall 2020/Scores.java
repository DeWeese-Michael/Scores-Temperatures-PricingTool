import java.util.Random;
public class Scores{

public static void main(String[] args){

Random rand = new Random();

int[] astericks = new int[10];


for(int i = 0; i < astericks.length; i++){
astericks[i] = rand.nextInt(101);
}//for loop


for(int i = 0; i < astericks.length; i++){
System.out.print(astericks[i]);
System.out.print(":");
for(int j = 0; j < astericks[i]; j++)
{
System.out.print("*");
}//inner for loop
System.out.println();
}//outer for loop

}//main method

}//class